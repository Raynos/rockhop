/** Offline selected75 grip-profile authoring; original asset/rest untouched.
 * No images/textures, rest/asset edits, or production changes. Results unaccepted.
 */
import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Matrix4,Quaternion,Vector3,Object3D,Triangle,Ray} from 'three';
import {MeshoptDecoder} from 'three/addons/libs/meshopt_decoder.module.js';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const V=a=>new Vector3().fromArray(a),I=()=>new Matrix4(),Q=()=>new Quaternion();
await MeshoptDecoder.ready;
function load(file) {
  const bytes=fs.readFileSync(file), length=bytes.readUInt32LE(12), d=JSON.parse(bytes.subarray(20,20+length));
  assert(bytes.toString('ascii',0,4)==='glTF'); const bin=bytes.subarray(28+length), cache=new Map(), world=[];
  const view = i => {
    if(cache.has(i))return cache.get(i);
    const b=d.bufferViews[i], e=b.extensions?.EXT_meshopt_compression; let raw;
    if(e){raw=new Uint8Array(e.count*e.byteStride);MeshoptDecoder.decodeGltfBuffer(raw,e.count,e.byteStride,bin.subarray(e.byteOffset,e.byteOffset+e.byteLength),e.mode,e.filter);}
    else {assert(b.buffer===0);raw=bin.subarray(b.byteOffset??0,(b.byteOffset??0)+b.byteLength);}
    const dv=new DataView(raw.buffer,raw.byteOffset,raw.byteLength);cache.set(i,dv);return dv;
  };
  const read = i => {
    const a=d.accessors[i], b=d.bufferViews[a.bufferView], dv=view(a.bufferView), components={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16}[a.type];
    assert(!a.sparse);const [method,width,denom]={5120:['getInt8',1,127],5122:['getInt16',2,32767],5121:['getUint8',1,255],5123:['getUint16',2,65535],5125:['getUint32',4,4294967295],5126:['getFloat32',4,1]}[a.componentType];
    return {count:a.count,get:(row,k=0)=>Math.max(a.normalized?-1:-Infinity,dv[method]((a.byteOffset??0)+row*(b.byteStride??width*components)+k*width,true)/(a.normalized?denom:1)),row(row){return Array.from({length:components},(_,k)=>this.get(row,k));}};
  };
  function walk(i,parent=I()) {const n=d.nodes[i], m=n.matrix?I().fromArray(n.matrix):I().compose(V(n.translation??[0,0,0]),new Quaternion().fromArray(n.rotation??[0,0,0,1]),V(n.scale??[1,1,1]));world[i]=parent.clone().multiply(m);for(const c of n.children??[])walk(c,world[i]);}
  for(const i of d.scenes[d.scene??0].nodes)walk(i);
  const node = name => {const i=d.nodes.findIndex(n=>n.name===name);assert(i>=0,name);return {i,n:d.nodes[i],world:world[i],point:new Vector3().setFromMatrixPosition(world[i])};};
  return {d,read,node,sha256:sha(bytes),file};
}
const output=process.argv[2];assert(output,'Fresh output directory');fs.mkdirSync(output,{recursive:true});assert(!fs.existsSync(output+'/profile.json'));
const sourcePath='harness/out/rider-rebuild/download-opt01/textures01/composition01/rider.glb',source=load(sourcePath),d=source.d,meta=JSON.parse(fs.readFileSync('harness/out/rider-rebuild/download-opt01/delivery01/rider-contract.json'));assert(source.sha256===meta.glbSHA256);
const nodes=d.nodes.map(n=>{const o=new Object3D();o.name=n.name;o.position.fromArray(n.translation??[0,0,0]);o.quaternion.fromArray(n.rotation??[0,0,0,1]);o.scale.fromArray(n.scale??[1,1,1]);return o;});d.nodes.forEach((n,i)=>{for(const c of n.children??[])nodes[i].add(nodes[c]);});const root=new Object3D();root.quaternion.fromArray(meta.driver.assetToBikeQuaternionXYZW);for(const i of d.scenes[d.scene??0].nodes)root.add(nodes[i]);root.updateMatrixWorld(true);
const bone=name=>nodes.find(n=>n.name===name),P=name=>bone(name).getWorldPosition(new Vector3()),rest=nodes.map(n=>({p:n.position.clone(),q:n.quaternion.clone(),s:n.scale.clone()}));
const reset=()=>{nodes.forEach((n,i)=>{n.position.copy(rest[i].p);n.quaternion.copy(rest[i].q);n.scale.copy(rest[i].s);});root.updateMatrixWorld(true);};
const basis=(f,n)=>{const y=n.clone().normalize(),x=f.clone().addScaledVector(y,-f.dot(y)).normalize();assert(x.lengthSq()>.99);return I().makeBasis(x,y,new Vector3().crossVectors(x,y));};
const history=JSON.parse(fs.readFileSync('docs/evidence/hero-remaster/one-rider-v2/rig-adapter01/bike-grip-surface02/report.json'));
const bikes=history.results.map(r=>{const g=load('public/models/'+r.asset);assert(g.sha256===r.sourceSHA256);return {receipt:r,shift:g.node('attach_frame_origin').point};});
const report={accepted:false,source:{path:sourcePath,sha256:source.sha256},recipeSHA256:sha(fs.readFileSync(new URL(import.meta.url))),sides:[],limits:['Offline candidate only. No played lean, wrist/elbow or device acceptance.','Current source geometry, selected materials/textures, native rest, shared75skin and inverse binds remain immutable.','The rigid palm patch is selected from exact glove surface with exclusively wrist/metacarpal positive fields.','Sparse digit samples drive a bounded local solve; full finite-bar checks are reported separately.','Thumb CMC opposition is a distinct explicit local-Y rotation bounded +/-45degrees; its anatomy/art remain reviewable, unaccepted.']};
const profile={accepted:false,schema:'rockhop-selected-grip-profile-v1',sourceSHA256:source.sha256,sourceContractSHA256:sha(fs.readFileSync('harness/out/rider-rebuild/download-opt01/delivery01/rider-contract.json')),bikes:bikes.map(b=>({asset:b.receipt.asset,sha256:b.receipt.sourceSHA256})),hands:{}};
for(const side of ['left','right']){
 reset();const hand=meta.specification.hands[side],w=bone(hand.wristJointId),palm=bone(hand.socketNodeName),w0=w.matrixWorld.clone(),socket=w0.clone().invert().multiply(palm.matrixWorld);
 const f=P(hand.forwardJointId).sub(P(hand.wristJointId)).normalize(),r=P(hand.radialJointId).sub(P(hand.ulnarJointId));r.addScaledVector(f,-r.dot(f)).normalize();const n=new Vector3().crossVectors(f,r).multiplyScalar(hand.normalSign).normalize();
 const align=Q().setFromRotationMatrix(basis(V([1,-.25,0]),V([0,-1,0])).multiply(basis(f,n).invert())),socketQ=align.clone().multiply(w.getWorldQuaternion(Q())).multiply(Q().setFromRotationMatrix(socket)).normalize(),grip=V([.27,.78,meta.driver.sideZ[side]*.33]),target=I().compose(grip,socketQ,V([1,1,1])).multiply(socket.clone().invert());
 const place=matrix=>{const q=Q().setFromRotationMatrix(matrix).normalize(),p=new Vector3().setFromMatrixPosition(matrix),parentQ=w.parent.getWorldQuaternion(Q()).normalize();w.position.copy(w.parent.worldToLocal(p));w.quaternion.copy(parentQ.invert().multiply(q));root.updateMatrixWorld(true);};place(target);
 const gn=source.node('ActualSelectedGlove.'+(side==='left'?'L':'R')),prim=d.meshes[gn.n.mesh].primitives[0],a=prim.attributes,pos=source.read(a.POSITION),normal=source.read(a.NORMAL),j=source.read(a.JOINTS_0),wt=source.read(a.WEIGHTS_0),idx=source.read(prim.indices),skin=d.skins[gn.n.skin],ibm=source.read(skin.inverseBindMatrices),ibms=skin.joints.map((_,i)=>I().fromArray(ibm.row(i))),names=skin.joints.map(i=>d.nodes[i].name);
 const sourceRows=Array.from({length:pos.count},(_,i)=>({p:V(pos.row(i)),n:V(normal.row(i)),fields:Array.from({length:4},(_,k)=>({joint:j.get(i,k),weight:wt.get(i,k)})).filter(f=>f.weight>0)}));
 const matrices=()=>skin.joints.map((node,i)=>nodes[node].matrixWorld.clone().multiply(ibms[i]));
 const skinned=(row,m)=>{const p=new Vector3(),n=new Vector3();for(const field of row.fields){p.addScaledVector(row.p.clone().applyMatrix4(m[field.joint]),field.weight);n.addScaledVector(row.n.clone().transformDirection(m[field.joint]),field.weight);}return {p,n:n.normalize()};};
 let m=matrices(),positions=new Float64Array(pos.count*3);sourceRows.forEach((row,i)=>positions.set(skinned(row,m).p.toArray(),i*3));const point=i=>new Vector3().fromArray(positions,i*3);
 const rigid=new Set([hand.wristJointId,...names.filter(name=>name.startsWith('DEF-palm.')&&name.endsWith(side==='left'?'.L':'.R'))]),rigidRow=row=>row.fields.every(f=>rigid.has(names[f.joint]));
 let pad=null;for(const offset of [[0,0,0],[.01,0,0],[-.01,0,0],[0,0,.01],[0,0,-.01]]){const ray=new Ray(grip.clone().add(V(offset)),V([0,-1,0]));for(let i=0;i<idx.count;i+=3){const ids=[idx.get(i),idx.get(i+1),idx.get(i+2)];if(!ids.every(id=>rigidRow(sourceRows[id])))continue;const t=new Triangle(...ids.map(point)),p=ray.intersectTriangle(t.a,t.b,t.c,false,new Vector3());if(!p)continue;const normal=t.getNormal(new Vector3());if(normal.y>-.5)continue;const distance=p.distanceTo(ray.origin);if(!pad||distance<pad.distance)pad={point:p,normal,distance,triangle:i/3,rows:ids,barycentric:t.getBarycoord(p,new Vector3()).toArray()};}}
 assert(pad,'Rigid selected palm-pad surface witness missing');
 const patch=[];sourceRows.forEach((row,i)=>{if(!rigidRow(row))return;const p=point(i);if(p.distanceTo(pad.point)>.012)return;const sample=skinned(row,m);if(sample.n.dot(pad.normal)>.7)patch.push(sample.n);});assert(patch.length>4);const patchN=patch.reduce((sum,v)=>sum.add(v),new Vector3()).normalize();
 const old=bikes[0].receipt.grips.find(g=>g.side===(meta.driver.sideZ[side]>0?'L':'R')),map=new Map(old.sourceMeshSurface.vertices.map(v=>[v.sourceVertex,V(v.point).sub(bikes[0].shift)]));
 const triangles=old.sourceMeshSurface.triangles.map(t=>new Triangle(...t.map(id=>map.get(id))));
 const ray=new Ray(grip,V([0,1,0])),barHits=triangles.map((t,i)=>{const p=ray.intersectTriangle(t.a,t.b,t.c,false,new Vector3());return p?{p,n:t.getNormal(new Vector3()),triangle:i}:null;}).filter(Boolean).sort((a,b)=>a.p.distanceTo(grip)-b.p.distanceTo(grip));assert(barHits.length);const bar=barHits[0];if(bar.n.y<0)bar.n.negate();
 const padInWrist=pad.point.clone().applyMatrix4(w.matrixWorld.clone().invert()),normalInWrist=patchN.clone().transformDirection(w.matrixWorld.clone().invert()),forwardInWrist=V([1,-.25,0]).transformDirection(w.matrixWorld.clone().invert());
 const newQ=Q().setFromRotationMatrix(basis(V([1,0,0]),bar.n.clone().negate()).multiply(basis(forwardInWrist,normalInWrist).invert())).normalize(),newP=bar.p.clone().addScaledVector(bar.n,.0005).sub(padInWrist.clone().applyQuaternion(newQ)),wristMatrix=I().compose(newP,newQ,V([1,1,1]));place(wristMatrix);
 const nearest=p=>{let best={distance:Infinity};for(let i=0;i<triangles.length;i++){const t=triangles[i],q=t.closestPointToPoint(p,new Vector3()),distance=p.distanceTo(q);if(distance<best.distance){let n=t.getNormal(new Vector3());const axisA=V(old.recipeAxis.a).sub(bikes[0].shift),axisU=V(old.recipeAxis.unit),centre=t.getMidpoint(new Vector3()),radial=centre.clone().sub(axisA);radial.addScaledVector(axisU,-radial.dot(axisU));if(n.dot(radial)<0)n.negate();best={distance,signed:Math.sign(p.clone().sub(q).dot(n)) * distance,q,n,triangle:i};}}return best;};
 const digitResults={};
 for(const [digit,chain]of Object.entries(hand.digits)){
  const chainSet=new Set(chain),all=[];const startM=matrices();
  sourceRows.forEach((row,i)=>{if(i%12)return;const dominant=row.fields.reduce((a,b)=>a.weight>b.weight?a:b),id=names[dominant.joint];if(!chainSet.has(id))return;const sample=skinned(row,startM);all.push({row:i,id,pad:sample.n.dot(bar.n.clone().negate())>.4});});
  const segments=chain.map(id=>{let rows=all.filter(v=>v.id===id&&v.pad);assert(rows.length>8,'Digit pad sample coverage '+id);const step=Math.max(1,Math.floor(rows.length/16));return rows.filter((_,i)=>i%step===0).slice(0,16);});
  const probes=all.filter((_,i)=>i%Math.max(1,Math.floor(all.length/160))===0).slice(0,160);
  const max=chain.map(id=>meta.driver.digitFlex[side][id].maxRadians),isThumb=digit==='thumb',bounds=isThumb?[...max,Math.PI/4]:max;
  const set=angles=>{chain.forEach((id,i)=>{bone(id).quaternion.copy(rest[nodes.indexOf(bone(id))].q).multiply(Q().setFromAxisAngle(V(meta.driver.digitFlex[side][id].axisLocal),angles[i]));});if(isThumb)bone(chain[0]).quaternion.multiply(Q().setFromAxisAngle(V([0,1,0]),angles[3]));root.updateMatrixWorld(true);};
  const evaluate=angles=>{set(angles);const mm=matrices(),gaps=[],contacts=[];let cost=0,penetration=0;for(const probe of probes){const sample=skinned(sourceRows[probe.row],mm),near=nearest(sample.p);if(near.signed<0){penetration=Math.max(penetration,-near.signed);cost+=1000*near.signed**2;}}for(const rows of segments){const samples=rows.map(v=>{const sample=skinned(sourceRows[v.row],mm),near=nearest(sample.p);return {...v,...sample,...near,gloveNormal:sample.n};}).sort((a,b)=>Math.abs(a.signed-.0005)-Math.abs(b.signed-.0005));const contact=samples[0];cost+=30*(contact.signed-.0005)**2+2*Math.max(0,contact.gloveNormal.dot(contact.n)+.6)**2*.0001;contacts.push({row:contact.row,point:contact.p.toArray(),barPoint:contact.q.toArray(),signedGapM:contact.signed,normalDot:contact.gloveNormal.dot(contact.n)});gaps.push(contact.signed);}return {cost,contacts,gaps,penetration};};
  let angles=bounds.map((b,i)=>i===3?0:b*.65),best=evaluate(angles),evaluations=1;
  // Three cyclic, bounded golden-section coordinate minimizations; no parameter grid.
  for(let cycle=0;cycle<3;cycle++)for(let k=0;k<angles.length;k++){let lo=k===3?-bounds[k]:0,hi=bounds[k],a=hi-(hi-lo)*.61803398875,b=lo+(hi-lo)*.61803398875;const query=x=>{const v=[...angles];v[k]=x;evaluations++;return {x,angles:v,value:evaluate(v)};};let aa=query(a),bb=query(b);for(let it=0;it<9;it++){if(aa.value.cost<bb.value.cost){hi=b;b=a;bb=aa;a=hi-(hi-lo)*.61803398875;aa=query(a);}else{lo=a;a=b;aa=bb;b=lo+(hi-lo)*.61803398875;bb=query(b);}}const winner=aa.value.cost<bb.value.cost?aa:bb;if(winner.value.cost<best.cost){angles=winner.angles;best=winner.value;}}
  set(angles);const final=evaluate(angles);digitResults[digit]={jointIds:chain,anglesRadians:angles.slice(0,3),thumbOppositionRadians:isThumb?angles[3]:null,boundsRadians:bounds,evaluations,objective:final.cost,contacts:final.contacts,maximumSparsePenetrationM:final.penetration,sparseSamples:probes.length};
 }
 const finalM=matrices();let insideCount=0,maxPen=0,nearCount=0,maxPoint=null,checked=0;const boundsMin=new Vector3(Infinity,Infinity,Infinity),boundsMax=new Vector3(-Infinity,-Infinity,-Infinity);for(const t of triangles)for(const p of [t.a,t.b,t.c]){boundsMin.min(p);boundsMax.max(p);}boundsMin.addScalar(-.002);boundsMax.addScalar(.002);
 // Exhaustively check every hand-owned selected glove vertex inside finite grip AABB.
 sourceRows.forEach((row,i)=>{if(row.fields.some(f=>!rigid.has(names[f.joint])&&!Object.values(hand.digits).flat().includes(names[f.joint])))return;const p=skinned(row,finalM).p;if(p.x<boundsMin.x||p.y<boundsMin.y||p.z<boundsMin.z||p.x>boundsMax.x||p.y>boundsMax.y||p.z>boundsMax.z)return;checked++;const near=nearest(p);if(near.signed<0){insideCount++;if(-near.signed>maxPen){maxPen=-near.signed;maxPoint={row:i,point:p.toArray(),barPoint:near.q.toArray()};}}if(Math.abs(near.signed)<.001)nearCount++;});
 const selectedPadInWrist=I().compose(padInWrist,Q().setFromRotationMatrix(basis(forwardInWrist,normalInWrist)),V([1,1,1]));
 const entry={wristQuaternionBike:newQ.toArray(),wristPositionBike:newP.toArray(),selectedPalmPadInWrist:selectedPadInWrist.toArray(),finitePalmTargetBike:bar.p.clone().addScaledVector(bar.n,.0005).toArray(),selectedSurfaceWitness:{triangle:pad.triangle,rows:pad.rows,barycentric:pad.barycentric,sourceRigidBoneIds:[...rigid],normalPatchSamples:patch.length},digits:Object.fromEntries(Object.entries(digitResults).map(([digit,r])=>[digit,{jointIds:r.jointIds,flexRadians:r.anglesRadians,opposition:r.thumbOppositionRadians===null?null:{jointId:r.jointIds[0],axisLocal:[0,1,0],radians:r.thumbOppositionRadians},limitsRadians:r.boundsRadians}]))};profile.hands[side]=entry;
 report.sides.push({side,pad:entry.selectedSurfaceWitness,palmPointInWrist:padInWrist.toArray(),palmNormalInWrist:normalInWrist.toArray(),finiteBarContact:{point:bar.p.toArray(),normal:bar.n.toArray(),triangle:bar.triangle},wristBike:newP.toArray(),digits:digitResults,fullHandOwnedVertexCheck:{checkedInGripAABB:checked,insideCount,maximumPenetrationM:maxPen,nearSurfaceWithin1mm:nearCount,worst:maxPoint}});
 console.log(JSON.stringify(report.sides.at(-1)));
}
fs.writeFileSync(output+'/profile.json',JSON.stringify(profile,null,2)+'\n');fs.writeFileSync(output+'/report.json',JSON.stringify(report,null,2)+'\n');
