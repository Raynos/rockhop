import subprocess,json,hashlib
from pathlib import Path
p=Path('assets/blender/rider-rebuild/selected-sleeve-component47')
out=Path('harness/out/rider-rebuild/selected-sleeve-component47/intake01')
assert not out.exists() and not (p/'input01.json').exists()
blender=['/Applications/Blender.app/Contents/MacOS/Blender','-b','-t','2','--python-exit-code','1','--python',str(p/'component.py'),'--']
subprocess.run([*blender,'intake','harness/out/rider-rebuild/selected-glove-component41/component01/component-qualified.json',str(out)],check=True)
subprocess.run([*blender,'qualify-intake',str(out/'intake-pending.json')],check=True)
subprocess.run(['python3',str(p/'component.py'),'freeze',str(out/'intake-qualified.json'),str(p/'input01.json')],check=True)
r=json.loads((out/'intake-qualified.json').read_text())
c=json.loads((p/'input01.json').read_text())
assert r['protectedValidationPassed'] and r['exact75RestUnchanged'] and r['originalSelectedHoodieGeometryExactAfterReopen'] and r['nativeStorage']['reopenVerified']
assert c['pins']['fieldHelper']['sha256']=='09e24d646bbf013a1adb9a7bedc53dc29510507678dd40abbf11d1fe175e131a'
print(json.dumps({'acceptedArt':False,'status':r['status'],'native':r['native'],'input':str(p/'input01.json')}),flush=True)
