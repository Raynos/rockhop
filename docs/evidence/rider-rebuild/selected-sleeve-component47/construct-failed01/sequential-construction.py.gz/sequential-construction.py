import subprocess,json
from pathlib import Path
p=Path('assets/blender/rider-rebuild/selected-sleeve-component47')
out=Path('harness/out/rider-rebuild/selected-sleeve-component47/component01')
assert not out.exists()
blender=['/Applications/Blender.app/Contents/MacOS/Blender','-b','-t','2','--python-exit-code','1','--python']
subprocess.run([*blender,str(p/'sleeve47.py'),'--',str(p/'input01.json'),str(out)],check=True)
subprocess.run([*blender,str(p/'component.py'),'--','qualify',str(out/'construction-pending.json')],check=True)
r=json.loads((out/'construction.json').read_text())
assert r['protectedValidationPassed'] and r['exact75RestUnchanged'] and r['nativeStorage']['reopenVerified']
print(json.dumps({'acceptedArt':False,'status':r['status'],'native':r['native'],'receipt':str(out/'construction.json')}),flush=True)
