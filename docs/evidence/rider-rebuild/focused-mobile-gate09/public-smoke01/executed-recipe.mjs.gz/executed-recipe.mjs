/** Fresh boot/first-Garage and normal-clock silent phone-viewport candidate diagnosis. */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { preview } from 'vite';
import { webkit } from 'playwright';
import { register } from 'tsx/esm/api';
import { pathToFileURL } from 'node:url';
import { summarizeLoader } from '/Users/raynos/projects/games/rockhop/assets/blender/rider-rebuild/focused-mobile-gate09/loader-summary.mjs';
const arg = (key, fallback) => process.argv.find(value => value.startsWith(`--${key}=`))?.slice(key.length + 3) ?? fallback;
const input = path.resolve(arg('build', 'dist')), out = path.resolve(arg('out'));
const expected = JSON.parse(await fs.readFile(path.resolve(arg('expected'))));
for (const key of ['sourceSHA256', 'metadataSHA256', 'gripProfileSHA256']) assert(/^[a-f0-9]{64}$/.test(expected[key]), `Expected ${key} required`);
const backend = arg('backend', 'webkit'), seconds = Number(arg('seconds', '20'));
assert(['webkit', 'metal'].includes(backend)); assert(seconds >= 10 && seconds <= 30);
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
await fs.mkdir(path.dirname(out), {recursive: true});
await fs.mkdir(out, {recursive: false});
const target = 'https://playrockhop.vercel.app';
const readPublic = async path => {const res = await fetch(target + path, {signal: AbortSignal.timeout(20000)}); assert(res.ok, `Public ${path} failed`); return res.json();};
const version = await readPublic('/version.json?smoke=38007837120');
assert.equal(version.sha, 'd98497f6c4dd989b75169bb4919a86bb0bf05459', 'Actual public build');
const manifest = await readPublic('/rider-remaster-source.json?smoke=38007837120');
assert.equal(manifest.sha256, expected.sourceSHA256, 'Frozen source manifest identity');
assert.equal(manifest.contractSHA256, expected.metadataSHA256, 'Frozen raw contract identity');
const report = {expected, status: 'UNACCEPTED_RUNTIME_DIAGNOSIS', accepted: false, backend, buildVersion: version, selectedSource: manifest,
 recipeSHA256: sha(await fs.readFile(new URL(import.meta.url))), errors: [], navigations: [], requests: [], requestFailures: [], responses: [], scenarios: [],
 method: 'Actual public fresh cold boot and first Garage via trusted UI; old Mustard saved at startup, then remaster equipped once from resident documents. Normal production RAF only, no performance benchmark or manual ticks/quality/pose overrides.',
 limits: ['Mac hardware with phone viewport/touch/DPR is not physical iPhone hardware.', 'CPU submissions and RAF differ from GPU completion. Timer queries sampled asynchronously only when extension exists.', 'Lifecycle and warm performance measured in one fresh normal page. No physical-phone crash claim from absence on Mac.']};
function lifecycle() {
 const events = [], started = performance.timeOrigin;
 sessionStorage.setItem('rockhop.performance02.documentCount', String(Number(sessionStorage.getItem('rockhop.performance02.documentCount') ?? 0) + 1));
 const log = (kind, detail) => events.push({atMs: performance.now(), kind, detail});
 globalThis.window.__phoneLifecycle = {events, timeOrigin: started, documentCount: Number(sessionStorage.getItem('rockhop.performance02.documentCount'))};
 globalThis.window.addEventListener('webglcontextlost', event => log('context-lost', event.statusMessage), true);
 globalThis.window.addEventListener('webglcontextrestored', () => log('context-restored'), true);
 globalThis.window.addEventListener('pageshow', event => log('pageshow', {persisted: event.persisted}));
 globalThis.navigator.serviceWorker?.addEventListener('controllerchange', () => log('sw-controllerchange', globalThis.navigator.serviceWorker.controller?.scriptURL));
 let last = '';
 const observer = new globalThis.MutationObserver(() => {
  const loader = globalThis.document.querySelector('#loader'), text = loader?.textContent?.trim().replace(/\s+/g, ' ').slice(0, 1000) ?? 'REMOVED';
  const detail = {present: !!loader, text, download: loader?.dataset.download ?? null, setup: loader?.dataset.setup ?? null, done: loader?.dataset.done ?? null, step: loader?.querySelector('li.on')?.dataset.key ?? null, setupLine: loader?.querySelector('.gauge.su .line')?.textContent ?? null, downloadLine: loader?.querySelector('.gauge.dl .line')?.textContent ?? null};
  const signature = JSON.stringify(detail);
  if (signature !== last) {last = signature; log('loader', detail);}
 });
 observer.observe(globalThis.document, {childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['hidden', 'style', 'class', 'data-download', 'data-setup', 'data-done']});
}
function installMeter() {
 const owner = globalThis.window.__render, renderer = owner.renderer, gl = renderer.getContext();
 const ext = gl.getExtension('EXT_disjoint_timer_query_webgl2');
 const data = {rows: [], raf: [], gpu: [], disjoint: 0}; let active = true, rafId, frame = 0;
 const pending = [], wrappedRiders = new Map();
 const renderOriginal = owner.render, postOriginal = owner.debug.post.render;
 let riderMs = 0, postMs = 0, resetCount = 0;
 owner.debug.post.render = function(...args) { const start = performance.now(); try {return postOriginal.apply(this, args);} finally {postMs += performance.now() - start;} };
 owner.render = function(...args) {
  const rider = owner.debug.rider;
  if (!wrappedRiders.has(rider)) {
   const original = rider.update;
   const wrapped = function(...args) {const start = performance.now(), before = this.debug?.fullResetCount ?? 0; try {return original.apply(this, args);} finally {riderMs += performance.now() - start; resetCount += (this.debug?.fullResetCount ?? before) - before;}};
   rider.update = wrapped; wrappedRiders.set(rider, {original, wrapped});
  }
  const before = renderer.info.render.frame, start = performance.now(); riderMs = postMs = resetCount = 0;
  let query;
  if (ext && frame++ % 30 === 0 && !gl.getQuery(ext.TIME_ELAPSED_EXT, gl.CURRENT_QUERY)) {query = gl.createQuery(); gl.beginQuery(ext.TIME_ELAPSED_EXT, query);}
  let result; try {result = renderOriginal.apply(this, args);} finally {
   if (query) {gl.endQuery(ext.TIME_ELAPSED_EXT); pending.push(query);}
   for (let i = pending.length - 1; i >= 0; i--) if (gl.getQueryParameter(pending[i], gl.QUERY_RESULT_AVAILABLE)) {
    if (!gl.getParameter(ext.GPU_DISJOINT_EXT)) data.gpu.push(gl.getQueryParameter(pending[i], gl.QUERY_RESULT) / 1e6); else data.disjoint++;
    gl.deleteQuery(pending.splice(i, 1)[0]);
   }
   const end = performance.now(), submitted = renderer.info.render.frame > before;
   data.rows.push({atMs: end, cpuMs: end - start, riderMs, postMs, resetCount, submitted,
    calls: renderer.info.render.calls, triangles: renderer.info.render.triangles, phase: globalThis.window.__rockhop.phase(), tick: globalThis.window.__rockhop.frame(), meter: globalThis.document.querySelector('.fpsmeter')?.textContent});
  }
  return result;
 };
 function raf(now) {if (!active) return; data.raf.push(now); rafId = globalThis.requestAnimationFrame(raf);} rafId = globalThis.requestAnimationFrame(raf);
 globalThis.window.__phoneMeter = {startMs: performance.now(), extension: !!ext, reset() {data.rows.length = data.raf.length = data.gpu.length = 0; data.disjoint = 0; this.startMs = performance.now();}, result() {return {...data, startMs: this.startMs, endMs: performance.now(), extension: !!ext};}, stop() {active = false; globalThis.cancelAnimationFrame(rafId); owner.render = renderOriginal; owner.debug.post.render = postOriginal; for (const [rider, record] of wrappedRiders) if (rider.update === record.wrapped) rider.update = record.original; for (const query of pending) gl.deleteQuery(query);}};
}
const pct = values => {const sorted = [...values].sort((a,b) => a-b); return {p50: sorted[Math.floor(sorted.length*.5)] ?? null, p95: sorted[Math.floor(sorted.length*.95)] ?? null, max: sorted.at(-1) ?? null};};
let server, browser, context, page;
try {
 // Actual checked public deployment; no preview server or private build substitution.
 if (backend === 'webkit') browser = await webkit.launch({headless: true});
 else {register(); const {launchBrowser} = await import(pathToFileURL(path.resolve('harness/lib/browser.ts')).href); process.env.TRIALS_BROWSER_BACKEND = 'metal'; const launched = await launchBrowser({width: 844, height: 390}); browser = launched.browser; report.browserProbe = launched.probe; await launched.context.close();}
 context = await browser.newContext({viewport: {width: 844, height: 390}, deviceScaleFactor: 3, isMobile: true, hasTouch: true});
 await context.addInitScript(() => {localStorage.setItem('rockhop.onboarded', '1'); localStorage.setItem('rockhop.riderOutfit', 'street-mustard'); localStorage.setItem('rockhop.economy.v1', JSON.stringify({version: 1, wallet: 0, medals: {}, proOwned: true, equipped: 'rookie'}));});
 await context.addInitScript(lifecycle);
 page = await context.newPage(); page.setDefaultTimeout(120000);
 page.on('pageerror', error => report.errors.push(error.message));
 page.on('framenavigated', frame => {if (frame === page.mainFrame()) report.navigations.push({atMs: performance.now(), url: frame.url()});});
 page.on('requestfailed', request => report.requestFailures.push({url: request.url(), error: request.failure()?.errorText}));
 page.on('response', response => report.responses.push({url: response.url(), status: response.status(), fromServiceWorker: response.fromServiceWorker()}));
 page.on('request', request => report.requests.push({atMs: performance.now(), url: request.url(), type: request.resourceType()}));
 await page.goto(target + '/?audio=0&perf=1');
 await page.waitForSelector('.menu-screen.live .menu-item[data-id=garage]');
 await page.waitForSelector('#loader', {state: 'detached'});
 report.firstGarageBefore = await page.evaluate(() => ({lifecycle: globalThis.window.__phoneLifecycle, info: globalThis.window.__rockhop.info(), stats: globalThis.window.__rockhop.stats(), webdriver: globalThis.navigator.webdriver}));
 assert(report.firstGarageBefore.webdriver, 'Silent automation requires navigator.webdriver');
 const firstGarageStart = performance.now();
 await page.locator('.menu-screen.live .menu-item[data-id=garage]').click(); await page.waitForSelector('.garage-screen.live');
 await page.evaluate(() => globalThis.window.__render.whenReady());
 report.boot = await page.evaluate(() => ({lifecycle: globalThis.window.__phoneLifecycle, info: globalThis.window.__rockhop.info(), renderDetails: globalThis.window.__render.debugInfo({selectedTextures: true}), userAgent: globalThis.navigator.userAgent, viewport: [globalThis.innerWidth, globalThis.innerHeight], DPR: globalThis.devicePixelRatio, coarse: globalThis.matchMedia('(pointer: coarse)').matches, renderer: globalThis.window.__rockhop.stats(), phase: globalThis.window.__rockhop.phase()}));
 report.firstGarage = {readyMs: performance.now() - firstGarageStart, timeOriginUnchanged: report.firstGarageBefore.lifecycle.timeOrigin === report.boot.lifecycle.timeOrigin, documentCount: report.boot.lifecycle.documentCount, phase: report.boot.phase, navigations: report.navigations.length};
 const equipStart = performance.now(), requestsBeforeEquip = report.requests.length;
 await page.locator('button[data-outfit=street-remastered]').click();
 await page.locator('button[data-outfit=street-remastered][aria-pressed=true]').waitFor();
 await page.evaluate(() => globalThis.window.__render.whenReady());
 const equipMs = performance.now() - equipStart;
 await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
 const actual = await page.evaluate(() => {
  const rider = globalThis.window.__render.debug.rider, bones = new Set();
  (rider.scene ?? rider.root).traverse(object => {if (object.isSkinnedMesh) for (const bone of object.skeleton.bones) bones.add(bone.name);});
  return {info: globalThis.window.__rockhop.info(), details: globalThis.window.__render.debugInfo({selectedTextures: true}),
   nativeJointCount: bones.size, candidate: rider.debug.candidate, grip: rider.debug.handOnGrip,
   visibleMeshNames: (rider.scene ?? rider.root).getObjectsByProperty('isMesh', true).filter(mesh => mesh.visible).map(mesh => mesh.name)};
 });
 assert.equal(actual.details.riderSourceSHA256, expected.sourceSHA256);
 assert.equal(actual.details.riderNativeMetadataSHA256, expected.metadataSHA256);
 assert.equal(actual.details.riderGripProfileSHA256, expected.gripProfileSHA256);
 assert.equal(actual.nativeJointCount, 75);
 assert(actual.grip.every(Boolean), 'Actual bilateral contact flags');
 assert(actual.visibleMeshNames.length && actual.visibleMeshNames.every(name => !/helmet/i.test(name)), 'Unexpected selected helmet');
 for (const role of ['ActualSelectedGlove.L','ActualSelectedGlove.R','ActualSelectedBoot.L','ActualSelectedBoot.R','RiderHoodie','RiderJeans','RiderBody'])
  assert(actual.candidate.meshRoles.some(part => part.role === role || part.role.startsWith(role+'.primitive')), `Missing selected role ${role}`);
 assert.equal(actual.details.selectedTextures.unavailableTextures,0);
 assert.equal(actual.details.selectedTextures.incompleteTextures,0);
 assert.equal(actual.details.selectedTextures.compressedTextures,21);
 assert(!report.requests.slice(requestsBeforeEquip).some(row => row.url === manifest.url), 'Equip started another selected download');
 report.smoke = {equipMs, actual, requestsSinceEquip:report.requests.slice(requestsBeforeEquip)};
 report.scenarios.push({after:actual.info});
 await page.screenshot({path:path.join(out,'public-first-garage-remastered.png')});
 report.finalLifecycle = await page.evaluate(() => globalThis.window.__phoneLifecycle);
 report.loader = summarizeLoader(report.finalLifecycle.events);
 assert(report.loader.finished && report.loader.removed && !report.loader.reinserted, 'Loader did not finish once');
 assert.equal(report.loader.regressions.length, 0, 'Loader percentage regressed');
 report.lifecycleChecks = {singleDocument: report.navigations.length === 1 && report.finalLifecycle.documentCount === 1, timeOriginUnchanged: report.firstGarageBefore.lifecycle.timeOrigin === report.finalLifecycle.timeOrigin, contextLost: report.finalLifecycle.events.filter(row => row.kind === 'context-lost').length, contextRestored: report.finalLifecycle.events.filter(row => row.kind === 'context-restored').length, selectedSourceFetches: report.requests.filter(row => row.url === manifest.url).length, errors: report.errors.length, requestFailures: report.requestFailures.length, audioNull: report.boot.info.modules.audio === 'null' && report.scenarios.every(row => row.after.modules.audio === 'null')};
 assert(report.lifecycleChecks.singleDocument && report.lifecycleChecks.timeOriginUnchanged, 'Unexpected reload/timeOrigin change');
 assert(report.lifecycleChecks.contextLost === 0 && report.lifecycleChecks.contextRestored === 0, 'Unexpected rendering context loss');
 assert(report.lifecycleChecks.selectedSourceFetches === 1, 'Candidate should fetch once through boot/Garage/outfit/C1');
 assert(report.lifecycleChecks.errors === 0 && report.lifecycleChecks.requestFailures === 0 && report.lifecycleChecks.audioNull, 'Page or silent-automation regression');
 report.status = 'COMPLETE_PUBLIC_COLD_GARAGE_SMOKE_NOT_PHONE_ACCEPTANCE';
 report.textureLimit = 'Literal Three texture format/type and retained typed-array mip payloads; not measured GPU allocation. Mac results never qualify physical iPhone FPS.';
} catch (error) {report.failure = error.stack; try {report.failurePage = await page?.evaluate(() => ({lifecycle: globalThis.window.__phoneLifecycle, loader: globalThis.document.querySelector('#loader')?.textContent, info: globalThis.window.__rockhop?.info()}));} catch { /* A terminated page cannot provide a failure snapshot. */ } throw error;}
finally {await fs.writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2)); await context?.close(); await browser?.close(); server?.httpServer.close();}
