import subprocess,json
from pathlib import Path
base=Path('harness/out/rider-rebuild/selected-glove-component41')
py='assets/blender/rider-rebuild/selected-glove-component41/assemble.py'
blender=['/Applications/Blender.app/Contents/MacOS/Blender','-b','-t','2','--python-exit-code','1','--python',py,'--']
witness=base/'original01/protected.json'
config=Path('assets/blender/rider-rebuild/selected-glove-component41/assembly01.input.json')
out=base/'attached01'
assert not witness.exists() and not config.exists() and not out.exists()
subprocess.run([*blender,'witness',str(witness)],check=True)
subprocess.run(['python3',py,'--','freeze',str(base/'component01/component-qualified.json'),str(witness),str(config)],check=True)
subprocess.run([*blender,'assemble',str(config),str(out)],check=True)
subprocess.run([*blender,'qualify',str(out/'gloves-only-pending.json')],check=True)
r=json.loads((out/'gloves-only-qualified.json').read_text())
assert r['protectedValidationPassed'] and r['exact75RestUnchanged'] and r['nativeStorage']['reopenVerified']
print(json.dumps({'acceptedArt':False,'status':'SELECTED_GLOVE41_ATTACHED_AND_PROTECTED_CHECKED_SLEEVE_PENDING','native':r['native'],'receipt':str(out/'gloves-only-qualified.json')}))
