import os,sys,subprocess,json,time,threading
from pathlib import Path
out=Path(sys.argv[1]);guard=Path(sys.argv[2]);command=sys.argv[3:]
assert not out.exists()
stop=threading.Event(); rows=[]
def sample():
 row={'unixSeconds':time.time()}
 row['memoryGiB']=list(map(float,subprocess.check_output(['bash','/Users/raynos/projects/localai/bin/mem-gb.sh'],text=True).split()))
 row['pressureRaw']=subprocess.check_output(['sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True).strip()
 row['swapRaw']=subprocess.check_output(['sysctl','-n','vm.swapusage'],text=True).strip()
 try:
  state=json.loads(guard.read_text());pid=state.get('ownedChildPID');row['ownedChildPID']=pid
  if pid:
   table=[]
   for line in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines():
    values=line.split()
    if len(values)==3:table.append(tuple(map(int,values)))
   own={pid}
   while True:
    before=len(own);own.update(p for p,pp,r in table if pp in own)
    if len(own)==before:break
   row['ownedProcessRSSKiB']=[{'pid':p,'parent':pp,'rssKiB':r} for p,pp,r in table if p in own]
 except (FileNotFoundError,json.JSONDecodeError):pass
 rows.append(row)
 out.write_text(''.join(json.dumps(r)+'\n' for r in rows))
 return row
# Observe before launch; same exact original admission is the authority.
for i in range(40):
 row=sample();a,w,f=row['memoryGiB'];print('original admission wait',i,a,w,f,flush=True)
 if a<55 and a+w<68:break
 time.sleep(15)
else:raise SystemExit(75)
def observe():
 while not stop.wait(2):sample()
thread=threading.Thread(target=observe,daemon=True);thread.start()
env=dict(os.environ,GOMAXPROCS='2',OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',VECLIB_MAXIMUM_THREADS='2',NUMEXPR_NUM_THREADS='2')
try:code=subprocess.call(command,env=env)
finally:stop.set();thread.join(timeout=5);sample()
raise SystemExit(code)
