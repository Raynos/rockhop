import subprocess,json,sys,hashlib,shutil
from pathlib import Path
out=Path("harness/out/rider-rebuild/selected-ankle-field42/gameplay-rookie01")
media=out/"rider-actual-leans-rookie.mp4"
play=Path("harness/out/rider-rebuild/selected-ankle-field42/playback-rookie01")
assert not out.exists() and not play.exists()
recipe=Path("harness/rider-rebuild/gameplay-lean-review.mjs")
assert hashlib.sha256(recipe.read_bytes()).hexdigest()=="3b459d6ba99bb90e0bb4d500e4be6b301834bc3f54c96310daf7339c7dbc1475"
subprocess.run(["node","--import","tsx",str(recipe),"--backend=metal","--camera-yaw=1.4","--source=harness/out/rider-rebuild/selected-ankle-field42/runtime02/rider.glb","--contract=harness/out/rider-rebuild/selected-ankle-field42/runtime02/rider-contract.json","--out="+str(out),"--bike=rookie"],check=True)
r=json.loads((out/"report.json").read_text());p=r["played"]
assert not r["errors"] and not p["faults"] and p["ticks"]==1200 and len(p["motionSamples"])==241 and p["finalHash"]=="a0fa0c4b1b76ba5e"
assert r["camera"]["yaw"]==1.4 and all(s["debug"]["stageClip"] is None and s["debug"]["physicalPose"] and s["debug"]["allBoneFinite"] and len(s["joints"])==75 for s in p["motionSamples"])
subprocess.run(["ffmpeg","-nostdin","-v","error","-threads","2","-ss",str(r["readyOffsetSeconds"]+0.75),"-i",str(out/"gameplay-played.webm"),"-an","-c:v","libx264","-preset","fast","-crf","18","-pix_fmt","yuv420p","-threads","2","-filter_threads","2","-movflags","+faststart",str(media)],check=True)
subprocess.run(["node","docs/evidence/hero-remaster/audit-2026-10-07-agent2/play-film-sampled.mjs",str(play),str(media)],check=True)
print(json.dumps({"accepted":False,"status":"ACTUAL_PRO_CAPTURE_TRIM_AND_PLAYBACK_COMPLETE_PARENT_REVIEW_PENDING","report":str(out/"report.json"),"movie":str(media),"playback":str(play/"playback.json")}))
